from . import constant_docx1
from . import constant_docx2
