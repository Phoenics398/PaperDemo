from . import paper_docx1
from . import paper_docx2
from . import paper_md
from . import paper_pdf
